package com.Telusko;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SqServlet extends HttpServlet {

	public void doGet(HttpServletRequest req , HttpServletResponse res) throws IOException{
		
		int k = 0;
		Cookie cookies[] = req.getCookies(); //We are using array of cookies we are not using cookie but cookies as we are not sure about the cookie we are going to use
		
		for(Cookie c : cookies){
		if(c.getName().equals("k"))
			k = Integer.parseInt(c.getValue());
		}
		k = k*k;
		
		PrintWriter out = res.getWriter();
		out.println("Square is "+k);
		
	}
}
		
		//int k = 0;
		
		//		HttpSession session = req.getSession();
		
		// session.removeAttribute(k); this can be used to remove a value from a session
 		
		// int k = (int)session.getAttribute("k") ; //Attribute meaning it will simply return an object
		// Integer.parseInt(req.getParameter("k"));
		
		