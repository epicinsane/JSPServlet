package com.Telusko;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class AddServlet extends HttpServlet {

	 public void doGet(HttpServletRequest req , HttpServletResponse res) throws IOException, ServletException{
		 
		 int i = Integer.parseInt(req.getParameter("num1"));
		 int j = Integer.parseInt(req.getParameter("num2"));
		
		 int k = i + j;
		
		 
		 Cookie cookie = new Cookie("k",k+ ""); //just like a class cookie can be added ("" is used to get Integer value)
		 res.addCookie(cookie); // This is used to create a cookie for our request
		 
		 
//		 HttpSession session = req.getSession();  //this is for using session 
//		 session.setAttribute("k", k);
//		 
		 res.sendRedirect("sq"); //here after? this will add k="+k in the url // this is called url rewriting
		 
//		req.setAttribute("k",k); 
//		  
//		RequestDispatcher rd = req.getRequestDispatcher("sq");
//		rd.forward(req, res);
	 }
}